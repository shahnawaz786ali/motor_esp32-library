from setuptools import setup

setup(name='motor_esp32',
      version='0.1',
      description="This function will help to move motor",
      author="Shahnawaz",
      packages=['motor_esp32'],
      zip_safe=False)